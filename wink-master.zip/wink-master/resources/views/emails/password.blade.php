Hello,
<br>
Please follow this link to reset your password:
<br>
{{$link}}
